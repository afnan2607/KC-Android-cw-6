package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<Student> students = new ArrayList<>();
     //s1,s2,s3,s4
    //0,1,2,3

    int afnan=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView studentName , studentAge,studentGrade;
        ImageView studentImg;
        Button changeStudentBtn;

        studentName = findViewById(R.id.textView);
        studentAge = findViewById(R.id.textView3);
        studentGrade = findViewById(R.id.textView4);
        studentImg = findViewById(R.id.imageView);
        changeStudentBtn = findViewById(R.id.button);

        Student s1 = new Student("youssef" ,14, 12,R.drawable.sponge);
        Student s2 = new Student("salman", 13,10,R.drawable.hi);
        Student s3 = new Student("majed",15,11,R.drawable.bye);
        Student s4 = new Student("hamad",16,12,R.drawable.WOW);

        students.add(s1);
        students.add(s2);
        students.add(s3);
        students.add(s4);


        studentName.setText(s2.getStudentName());
        studentAge.setText(String.valueOf(s2.getStudentAge()));
        studentGrade.setText(String.valueOf(s2.getStudentGrade()));
        studentImg.setImageResource(s2.getStudentImg());
        changeStudentBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                afnan++;

                studentName.setText(s2.getStudentName());
                studentAge.setText(String.valueOf(s2.getStudentAge()));
                studentGrade.setText(String.valueOf(s2.getStudentGrade()));
                studentImg.setImageResource(s2.getStudentImg());
                changeStudentBtn.setOnClickListener(new View.OnClickListener() {





            }
        });






    }
}